
require([
    "jquery"
], function(){
    document.getElementById('adjustment_positive').disabled = true;
  	document.getElementById('shipping_amount').disabled = true;
  	document.getElementById('adjustment_negative').disabled = true;
});
